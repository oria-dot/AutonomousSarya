import redis
from rq import Queue
from clone_jobs import launch_clone_job

redis_conn = redis.Redis()
q = Queue("sarya_clone_queue", connection=redis_conn)

def queue_clone_launch(clone_name):
    q.enqueue(launch_clone_job, clone_name)