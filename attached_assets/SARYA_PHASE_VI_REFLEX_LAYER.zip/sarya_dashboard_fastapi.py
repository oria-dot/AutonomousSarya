from fastapi import FastAPI, APIRouter, HTTPException, Depends, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import logging

app = FastAPI(
    title="SARYA Reflex Intelligence API",
    description="Secured dashboard for clone triggering and reflex memory",
    version="1.0.0"
)

v1 = APIRouter(prefix="/v1")

# JWT Auth setup
security = HTTPBearer()
API_TOKEN = "secret-sarya-token"

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if credentials.credentials != API_TOKEN:
        raise HTTPException(status_code=403, detail="Unauthorized")

reflex_memory = []
status_log = {"status": "SARYA core running", "clones_launched": 0}

class CloneRequest(BaseModel):
    clone: str

@v1.get("/status")
def get_status():
    return status_log

@v1.post("/launch_clone/{clone_name}")
def launch_clone(clone_name: str, _: HTTPAuthorizationCredentials = Depends(verify_token)):
    reflex_memory.append(f"Clone triggered: {clone_name}")
    from clone_enqueue import queue_clone_launch
    queue_clone_launch(clone_name)
    logging.info(f"Clone '{clone_name}' launched.")
    return {"message": f"Clone '{clone_name}' successfully launched."}

@v1.get("/reflex_log")
def get_reflex_log(_: HTTPAuthorizationCredentials = Depends(verify_token)):
    return {"events": reflex_memory[-20:]}

app.include_router(v1)

@app.get("/")
def root():
    return {"message": "SARYA FastAPI Secured Interface - v1"}