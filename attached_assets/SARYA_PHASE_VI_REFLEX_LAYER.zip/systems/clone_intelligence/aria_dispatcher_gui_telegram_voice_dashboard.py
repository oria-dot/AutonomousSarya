# Unified SAYRA Dispatcher with GUI, Telegram, and Voice Sync

from telegram_bot import start_telegram_interface
from voice_persona_phase_2 import VoicePersona
from overwatch_panel import launch_dashboard

def full_dispatch():
    print("Launching SAYRA unified control system...")
    start_telegram_interface()
    VoicePersona().speak("Telegram link established.")
    launch_dashboard()

if __name__ == "__main__":
    full_dispatch()