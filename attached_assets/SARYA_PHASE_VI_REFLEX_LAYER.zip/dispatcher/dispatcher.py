
class Dispatcher:
    def __init__(self, memory=None):
        self.memory = memory
        self.handlers = {}

    def register(self, event_type, handler):
        if event_type not in self.handlers:
            self.handlers[event_type] = []
        self.handlers[event_type].append(handler)
        print(f"[DISPATCHER] Registered handler for event: {event_type}")

    def dispatch(self, event_type, data=None):
        if event_type in self.handlers:
            for handler in self.handlers[event_type]:
                handler(data)
                print(f"[DISPATCHER] Dispatched event '{event_type}' with data: {data}")
        else:
            print(f"[DISPATCHER] No handler found for event: {event_type}")
