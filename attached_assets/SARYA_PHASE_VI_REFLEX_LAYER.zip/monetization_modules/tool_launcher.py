import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Micro-SaaS Tool Launcher
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)
from micro_saas.invoice_generator import generate_invoice
from micro_saas.resume_booster import boost_resume

def launch_tool():
    """
    Runs micro-SaaS utilities like invoice generation and resume boosting.

    Returns:
        None
    """
    invoice = generate_invoice("Commander Corp", 1500)
    resume = boost_resume("John Doe - AI Specialist")

    log_status(f"[TOOL] Invoice generated: {invoice}")
    log_status(f"[TOOL] Resume boosted: {resume}")