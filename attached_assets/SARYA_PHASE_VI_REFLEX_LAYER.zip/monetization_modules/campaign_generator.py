
import random
from datetime import datetime

campaign_types = ["freelance outreach", "affiliate promo", "SaaS funnel", "crypto signal push"]

def generate_campaign(target, offer_type="SaaS funnel"):
    """TODO: Add documentation."""
    subject_lines = {
        "freelance outreach": "Your next top freelancer just landed.",
        "affiliate promo": "Insane results with this one link...",
        "SaaS funnel": "Boost your productivity with this new AI tool.",
        "crypto signal push": "The next breakout coin? Here's what AI says..."
    }

    hooks = {
        "freelance outreach": "I saw your projects and knew I had to reach out.",
        "affiliate promo": "This tool made me $2,000 in 14 days with zero followers.",
        "SaaS funnel": "We've helped 1,000+ creators earn more with less effort.",
        "crypto signal push": "These signals caught 3 of the last 5 mooners before they hit Twitter."
    }

    subject = subject_lines.get(offer_type, "Opportunity knocks.")
    hook = hooks.get(offer_type, "You’ve never seen results this fast.")

    campaign = {
        "timestamp": datetime.now().isoformat(),
        "target": target,
        "type": offer_type,
        "subject": subject,
        "hook": hook,
        "cta": "Want to try it out? I’ll set it up for you — just say the word."
    }

    print(f"[FunnelStorm] Campaign generated for {target}")
    print(f"Subject: {subject}")
    print(f"Hook: {hook}")
print(f"CTA: {campaign['cta']}")
    return campaign