
import random
from datetime import datetime

platforms = ["Twitter", "LinkedIn"]
tones = ["friendly", "confident", "urgent"]

def generate_dm(target_handle, offer_type="SaaS", tone="confident"):
    """TODO: Add documentation."""
    hooks = {
        "SaaS": {
            "friendly": "Hey! Just saw what you're working on—this AI tool could really help streamline your process.",
            "confident": "Your brand is strong. This AI tool will make it unstoppable.",
            "urgent": "Don't miss the window. Your competitors are already using this AI booster."
        },
        "freelance": {
            "friendly": "Thought I’d say hi — your posts are amazing. I’m a freelancer who can help lighten the load.",
            "confident": "Let’s get results. My freelance work speaks for itself.",
            "urgent": "Quick pitch: I can take this off your hands and deliver it fast."
        }
    }

    hook_line = hooks.get(offer_type, {}).get(tone, "Got something you’ll want to see.")
    dm = {
        "target": target_handle,
        "platform": random.choice(platforms),
        "tone": tone,
        "message": hook_line,
        "timestamp": datetime.now().isoformat()
    }

print(f"[DM_Reaper] DM for @{target_handle} on {dm['platform']}")
    print(f"Tone: {tone}")
    print(f"Message: {hook_line}")
    return dm