import pytest

def test_income_distribution_import():
    """TODO: Add documentation."""
    try:
        __import__("income_distribution")
    except ImportError:
        pytest.fail("Module income_distribution could not be imported")