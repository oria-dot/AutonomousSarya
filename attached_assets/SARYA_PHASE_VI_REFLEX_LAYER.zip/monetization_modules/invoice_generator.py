import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Invoice Generator Tool
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

def generate_invoice(client_name, amount):
    """
    Generates a formatted invoice message for a client.

    Args:
        client_name (str): Name of the client.
        amount (float): Amount billed.

    Returns:
        str: Invoice message string.
    """
    invoice = f"Invoice for {client_name}: ${amount}"
    log_status(f"Generated invoice for {client_name} - Amount: ${amount}")
    return invoice