import json
from datetime import datetime

EMOTION_MAP = {
    "clone triggered": "anticipation",
    "risk": "tension",
    "success": "satisfaction",
    "error": "frustration",
    "reflex": "awareness"
}

def interpret_emotion(event):
    for key, emotion in EMOTION_MAP.items():
        if key in event.lower():
            return emotion
    return "neutral"

def log_emotional_reflex(event):
    emotion = interpret_emotion(event)
    memory = {
        "timestamp": datetime.utcnow().isoformat(),
        "event": event,
        "emotion": emotion
    }
    with open("deep_reflex_emotion_log.json", "a", encoding="utf-8") as f:
        f.write(json.dumps(memory) + "\n")