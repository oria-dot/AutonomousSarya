#!/bin/bash

echo "== ARIA Cloud Deployment Bootstrap =="

echo "[1/5] Updating system packages..."
sudo apt update -y && sudo apt upgrade -y

echo "[2/5] Installing dependencies..."
sudo apt install python3-pip docker.io docker-compose -y

echo "[3/5] Cloning project (ensure GitHub SSH auth)..."
# git clone git@github.com:your-aria-project.git && cd your-aria-project

echo "[4/5] Building Docker containers..."
docker-compose build

echo "[5/5] Starting ARIA system..."
docker-compose up -d

echo "ARIA deployed successfully on your cloud host!"