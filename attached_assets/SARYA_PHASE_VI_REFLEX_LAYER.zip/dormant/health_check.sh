#!/bin/bash
# Health check script to ensure all containers are running smoothly

check_service() {
  SERVICE_NAME=$1
  PORT=$2
  RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:$PORT)
  if [ $RESPONSE -eq 200 ]; then
    echo "$SERVICE_NAME is running on port $PORT"
  else
    echo "$SERVICE_NAME is down!"
  fi
}

# Checking services
check_service "Trading Engine" 5000
check_service "Clone Management" 5001
check_service "Data Service" 5002
