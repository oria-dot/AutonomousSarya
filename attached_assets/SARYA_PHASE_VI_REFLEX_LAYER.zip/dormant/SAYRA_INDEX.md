# SAYRA SYSTEM INDEX

This is the master index of all modules in the SAYRA intelligence system.

- `aria_main.py` → `core/` — Status: ✅ Integrated
- `aria_dispatcher.py` → `core/` — Status: ✅ Integrated
- `aria_boot.py` → `core/` — Status: ✅ Integrated
- `aria_kernel.py` → `core/` — Status: ✅ Integrated
- `clone_commands_telegram.py` → `clones/` — Status: ✅ Integrated
- `clone_income_router.py` → `clones/` — Status: ✅ Integrated
- `clone_hub.py` → `clones/` — Status: ✅ Integrated
- `arima_forecasting.py` → `trading_ai/` — Status: ✅ Integrated
- `reinforcement_learning.py` → `trading_ai/` — Status: ✅ Integrated
- `strategic_reflex_loop.py` → `trading_ai/` — Status: ✅ Integrated
- `reflex_feedback_core.py` → `reflex/` — Status: ✅ Integrated
- `self_healing_layer.py` → `reflex/` — Status: ✅ Integrated
- `strategic_reflex_loop.py` → `reflex/` — Status: ✅ Integrated
- `aria_dispatcher_gui_telegram_voice_dashboard.py` → `voice_gui/` — Status: ✅ Integrated
- `voice_persona_phase_2.py` → `voice_gui/` — Status: ✅ Integrated
- `telegram_reflex_commands.py` → `voice_gui/` — Status: ✅ Integrated
- `grid_gui_launcher.py` → `voice_gui/` — Status: ✅ Integrated
- `aria_soul_codex.py` → `soul/` — Status: ✅ Integrated
- `emotion_voice_layer.py` → `soul/` — Status: ✅ Integrated
- `memory_engine.py` → `soul/` — Status: ✅ Integrated
- `income_core.py` → `income/` — Status: ✅ Integrated
- `gumroad_autopilot.py` → `income/` — Status: ✅ Integrated
- `telegram_bot.py` → `integrations/` — Status: ✅ Integrated
- `supabase_integration.py` → `integrations/` — Status: ✅ Integrated
- `encryption_utils.py` → `utils/` — Status: ✅ Integrated
- `utils.py` → `utils/` — Status: ✅ Integrated
- `unified_launch.py` → `launcher/` — Status: ✅ Integrated
- `run_all.py` → `launcher/` — Status: ✅ Integrated
