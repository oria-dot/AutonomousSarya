#!/bin/bash
# Run Kube-bench for Kubernetes security auditing

# Check if kube-bench is installed
if ! command -v kube-bench &> /dev/null
then
    echo "kube-bench could not be found, please install it first"
    exit
fi

# Running the security audit and saving results
echo "Running Kube-bench security audit..."
kube-bench > kube-bench-results.txt

echo "Audit completed. Check the results in kube-bench-results.txt for any vulnerabilities or recommendations."
