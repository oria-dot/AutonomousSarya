#!/bin/bash
echo "Running ARIA test suite..."
pytest