# ARIA System Module Map

This document explains the purpose of each file in the ARIA platform.

### `aria_api/main.py`
Exposes a FastAPI interface to control ARIA via HTTP endpoints (/run, /status, /logs).

### `aria_cli/main.py`
Command-line interface to trigger and test different ARIA modules.

### `aria_core/ai/agent_controller.py`
Uses LLM engine to process context and task into a system action/decision.

### `aria_core/ai/ai_agent_loop.py`
Controls the agent execution loop by feeding tasks into the LLM and acting on output.

### `aria_core/ai/llm_engine.py`
Wraps OpenAI's GPT to allow ARIA to make intelligent, text-based decisions.

### `aria_core/auto/ai_agent_orchestrator.py`
Combines module registry and LLM controller to execute dynamic AI agent cycles.

### `aria_core/auto/auto_healer.py`
Wraps any function or module call with smart error recovery logic to ensure system resilience.

### `aria_core/auto/module_registry.py`
Scans all plugin files and registers modules that have a .run() method.

### `aria_core/context/context.py`
Defines the ARIAContext class, holding global state and signal data shared across modules.

### `aria_core/logging/logger.py`
Provides a centralized logger factory for uniform logging across the entire ARIA system.

### `aria_core/signals/bus.py`
Implements a basic SignalBus to publish and retrieve system signals.

### `aria_plugins/clones/social_ghost.py`
Creates and deploys ghost clones across simulated social platforms.

### `aria_plugins/personas/voice_persona.py`
Expresses text through a persona tone (e.g. Calm, Confident).

### `aria_plugins/strategies/quantum_loop.py`
Simulated decision-making strategy plugin; AI-based macro-response handler.

### `clone_expansion_framework.py`
Registers, replicates, and tracks clones across modules or platforms.

### `config/settings.yaml`
Placeholder for global system configuration (can include LLM model, task templates).

### `emotion_voice_layer.py`
Converts text messages into emotionally framed outputs (e.g. friendly, assertive).

### `freelance_empire_bot.py`
Applies to online freelance jobs and accepts payment across multiple channels.

### `micro_saas_builder.py`
Simulates generation and metadata creation for Micro-SaaS tools and apps.

### `requirements.txt`
Lists all Python dependencies including FastAPI, OpenAI SDK, and utilities.

### `security_guardian_phase_2.py`
Evaluates anomaly signals and changes ARIA's security posture (Green, Yellow, Red).

### `social_media_ghost_cloner.py`
Handles multi-platform ghost identity deployment (brand automation bots).

### `start.sh`
Starts the FastAPI backend locally with hot reload enabled.

