# ARIA Deployment Checklist

## 1. Installation

```bash
git clone <repo-url>
cd ARIA
pip install -r requirements.txt
```

## 2. Running Tests

```bash
chmod +x test.sh
./test.sh
```

## 3. Docker Deployment

### Build and Run

```bash
docker-compose build
docker-compose up
```

### Stop and Clean

```bash
docker-compose down
```

## 4. Manual CLI Run

```bash
python aria_unified_main.py
```

## 5. Config Management

Edit `config/aria_config.yaml` to enable or disable modules and set logging.

## 6. CI/CD Integration

This project includes a GitHub Actions workflow:
- On every push to `main`, runs `pytest` with coverage.

## 7. Logs

Logs saved to:
- `logs/aria.log`
- Rotated automatically via loguru

## 8. Updating Modules

All modules should inherit from `aria_core.base_module.BaseModule` and implement:
```python
def run(self):
    ...
```