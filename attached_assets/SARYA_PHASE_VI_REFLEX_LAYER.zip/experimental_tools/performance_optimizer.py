import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Performance Optimization Layer: Multi-Core, Parallel Execution, Load Balancing
import asyncio
import concurrent.futures
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

def optimize_parallel_tasks(tasks):
    """
    Runs a list of synchronous tasks in parallel using a thread pool.

    Args:
        tasks (list): Callable objects to be executed in parallel.

    Returns:
        list: List of task return values.
    """
    with concurrent.futures.ThreadPoolExecutor() as executor:
        results = list(executor.map(lambda task: task(), tasks))
    return results

def allocate_task_load(task, cores=4):
    """
    Duplicates a task across multiple cores for load balancing.

    Args:
        task (callable): Function to run in parallel.
        cores (int): Number of concurrent workers to use.

    Returns:
        list: Result from each parallel task instance.
    """
    log_status(f"Allocating task to {cores} cores")
    return optimize_parallel_tasks([task for _ in range(cores)])