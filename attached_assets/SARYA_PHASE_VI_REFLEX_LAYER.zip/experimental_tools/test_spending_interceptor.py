import pytest
import os

# Auto-generated test scaffold for module: spending_interceptor

def test_spending_interceptor_basic_import():
    try:
import spending_interceptor
    except Exception as e:
        pytest.fail(f"Failed to import spending_interceptor: {e}")
