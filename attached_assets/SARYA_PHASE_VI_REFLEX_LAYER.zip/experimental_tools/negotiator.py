
import random

def generate_negotiation_response(tone="confident"):
    """TODO: Add documentation."""
    templates = {
        "confident": [
            "I'm confident this solution fits your needs perfectly.",
            "Based on your goals, I suggest we proceed at the offered rate."
        ],
        "friendly": [
            "I'm happy to adjust things to make sure you're satisfied.",
            "Let's collaborate and make this a win-win!"
        ],
        "urgent": [
            "Let's secure this opportunity before it closes.",
            "Time-sensitive deals require fast action—let’s move."
        ]
    }
return random.choice(templates.get(tone, templates["confident"]))

def negotiate_with_client(client_name, tone="confident"):
    """TODO: Add documentation."""
    print(f"Negotiating with {client_name} using a {tone} tone...")
    response = generate_negotiation_response(tone)
    print(f"Negotiation Message: {response}")