import pytest
import os

# Auto-generated test scaffold for module: env_loader

def test_env_loader_basic_import():
    try:
import env_loader
    except Exception as e:
        pytest.fail(f"Failed to import env_loader: {e}")
