import pytest
import os

# Auto-generated test scaffold for module: funnel_splitter

def test_funnel_splitter_basic_import():
    try:
import funnel_splitter
    except Exception as e:
        pytest.fail(f"Failed to import funnel_splitter: {e}")
