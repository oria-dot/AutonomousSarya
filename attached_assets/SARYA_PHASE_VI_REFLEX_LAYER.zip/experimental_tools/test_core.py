import pytest

def test_core_import():
    """TODO: Add documentation."""
    try:
        __import__("core")
    except ImportError:
        pytest.fail("Module core could not be imported")