"""
MacroeconomicEngine – Simulates or fetches macroeconomic indicators
"""

import logging

class MacroeconomicEngine:
    """
    Engine for injecting macroeconomic signals into a shared context.
    """

    def __init__(self, context, source=None):
        """
        Initialize with context and optional external data source.

        :param context: Shared system context holding signal state.
        :param source: Optional callable to fetch live data.
        """
        self.context = context
        self.source = source
        self.logger = logging.getLogger(__name__)

    def analyze(self):
        """
        Update context with macroeconomic indicators, either simulated or fetched.

        :return: Dict of macroeconomic signals.
        """
        try:
            if self.source:
                data = self.source()
            else:
                data = {
                    "inflation": 3.2,
                    "gdp_growth": 2.1,
                    "interest_rate": 5.25,
                    "risk_index": "moderate"
                }

            self.context.signals["macro"] = data
            return data

        except Exception as e:
            self.logger.error(f"MacroeconomicEngine failed: {e}")
            return {}