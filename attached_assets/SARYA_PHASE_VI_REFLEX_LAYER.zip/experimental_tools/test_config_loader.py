import pytest
import os

# Auto-generated test scaffold for module: config_loader

def test_config_loader_basic_import():
    try:
import config_loader
    except Exception as e:
        pytest.fail(f"Failed to import config_loader: {e}")
