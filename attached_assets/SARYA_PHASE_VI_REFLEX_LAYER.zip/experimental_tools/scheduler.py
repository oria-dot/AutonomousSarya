import schedule
import time
from threading import Thread
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

class AriaScheduler:
    """
    Simple wrapper around `schedule` to allow ARIA subsystems to run on intervals.
    """

    def __init__(self):
"""TODO: Add documentation."""
        self.jobs = []

    def register_job(self, interval, unit, func, tag=None):
        """
        Registers a job to run at a set interval.

        Args:
            interval (int): How often to run.
            unit (str): 'seconds', 'minutes', 'hours'.
            func (callable): Function to run.
            tag (str): Optional identifier.
        """
        job = getattr(schedule.every(interval), unit).do(func)
        if tag:
            job.tag(tag)
        self.jobs.append(job)
        log_status(f"[SCHEDULER] Registered job every {interval} {unit}: {func.__name__}")

    def start(self):
        """
        Starts the scheduler loop on a background thread.
        """
        def run_loop():
    """TODO: Add documentation."""
            while True:
                schedule.run_pending()
                time.sleep(1)
        thread = Thread(target=run_loop, daemon=True)
        thread.start()
        log_status("[SCHEDULER] Background scheduler thread started.")