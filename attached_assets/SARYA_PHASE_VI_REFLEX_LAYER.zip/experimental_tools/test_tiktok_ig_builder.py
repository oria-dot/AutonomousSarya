import pytest
import os

# Auto-generated test scaffold for module: tiktok_ig_builder

def test_tiktok_ig_builder_basic_import():
    try:
import tiktok_ig_builder
    except Exception as e:
        pytest.fail(f"Failed to import tiktok_ig_builder: {e}")
