
import os

DORMANT_PATH = "dormant"
FRAGMENTS_PATH = "lab_fragments"
HEAL_LOG = "sarya_heal_log.txt"

def scan_and_log(directory):
    log = []
    for filename in os.listdir(directory):
        if filename.endswith(".py"):
            path = os.path.join(directory, filename)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                # Basic check
                if "def " in content or "class " in content:
                    log.append(f"Healable: {filename}")
                else:
                    log.append(f"Minimal logic: {filename}")
            except Exception as e:
                log.append(f"Unreadable: {filename}")
    return log

def run_healing_scan():
    log_entries = ["[SARYA HEAL MODULE] Scanning..."]
    log_entries += scan_and_log(DORMANT_PATH)
    log_entries += scan_and_log(FRAGMENTS_PATH)
    with open(HEAL_LOG, "w", encoding="utf-8") as f:
        f.write("\n".join(log_entries))
    print("[SARYA HEAL MODULE] Scan complete. Log saved to", HEAL_LOG)

if __name__ == "__main__":
    run_healing_scan()
