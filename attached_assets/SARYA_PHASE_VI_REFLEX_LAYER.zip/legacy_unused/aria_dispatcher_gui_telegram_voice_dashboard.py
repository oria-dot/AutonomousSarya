
# aria_dispatcher_gui_telegram_voice_dashboard.py

# [FIXED] from core.sarya_interface import handle_command (original import disabled — module not found)

class DashboardDispatcher:
    def __init__(self):
        self.log = []

    def display_status(self):
        print("[DASHBOARD] Current operational status:")
        print(" - Commands sent:", len(self.log))
        for entry in self.log:
            print("   >", entry)

    def dispatch_from_dashboard(self, command):
        print(f"[DASHBOARD] Dispatching: {command}")
        self.log.append(command)
        handle_command(command)

    def run_demo(self):
        test_inputs = ["/status", "/emotion", "/heal", "/clone"]
        for cmd in test_inputs:
            self.dispatch_from_dashboard(cmd)
        self.display_status()

if __name__ == "__main__":
    print("[SARYA DASHBOARD DISPATCHER] Online.")
    panel = DashboardDispatcher()
    panel.run_demo()
