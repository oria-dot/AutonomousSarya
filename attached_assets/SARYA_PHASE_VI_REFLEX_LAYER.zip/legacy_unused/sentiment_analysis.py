"""
sentiment_analysis.py — Regenerated
Purpose: Analyzes text or news input for sentiment score and category.
"""

from textblob import TextBlob

def analyze_sentiment(text):
    """TODO: Add documentation."""
    blob = TextBlob(text)
    score = blob.sentiment.polarity
    category = "Positive" if score > 0 else "Negative" if score < 0 else "Neutral"
    return {"score": score, "category": category}

def test_sample_sentiments():
    """TODO: Add documentation."""
    samples = [
        "This stock is booming!",
        "The market is crashing horribly.",
        "No major news today."
    ]
    for text in samples:
        result = analyze_sentiment(text)
print(f"Text: '{text}' | Sentiment: {result['category']} ({result['score']:.2f})")

if __name__ == "__main__":
    test_sample_sentiments()