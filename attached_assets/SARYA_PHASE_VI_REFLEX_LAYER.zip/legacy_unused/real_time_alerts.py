# real_time_alerts.py – Fixed

def build_email(subject, body):
    """TODO: Add documentation."""
    message = f"Subject: {subject}\n"
    message += f"{body}"
    return message