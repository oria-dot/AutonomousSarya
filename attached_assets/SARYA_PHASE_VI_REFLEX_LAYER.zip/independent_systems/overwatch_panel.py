import sarya_engine
from auth_utils import require_api_key

# Overwatch Master Panel (Flask UI for Aria Control Center)

from flask import Flask, jsonify, request
from clone_hub import CloneHub
from income_core import IncomeAutomationCore
from aria_soul_codex import AriaSoulCodex

app = Flask(__name__)

clone_hub = CloneHub()
income_core = IncomeAutomationCore()
memory_engine = AriaSoulCodex()

@app.route("/")
def root():
    """TODO: Add documentation."""
    return {
        "Aria Overwatch Online": True,
"endpoints": ["/clones", "/income", "/memory", "/dispatch", "/assign"]
    }

@app.route("/clones", methods=["GET"])
def get_clones():
    """TODO: Add documentation."""
    return jsonify(clone_hub.status_report())

@app.route("/income", methods=["GET"])
def get_income():
    """TODO: Add documentation."""
    return jsonify(income_core.get_income_summary())

@app.route("/memory", methods=["GET"])
def get_memory():
    """TODO: Add documentation."""
    return jsonify(memory_engine.memory_archive[-10:])

@app.route("/assign", methods=["POST"])
def assign_mission():
    """TODO: Add documentation."""
    data = request.get_json()
    name = data.get("name")
    mission = data.get("mission")
    result = clone_hub.deploy_clone(name, mission)
    return jsonify({"result": result})

@app.route("/dispatch", methods=["GET"])
def trigger_dispatch():
    """TODO: Add documentation."""
    income_core.add_income("Freelance", 150)
    income_core.add_income("Gumroad", 250)
    income_core.add_income("SaaS", 600)
    distribution = income_core.run()
    memory_engine.store_memory(f"Dispatch executed. Funds distributed: {distribution}")
    return jsonify({"result": "Dispatcher activated", "distribution": distribution})

if __name__ == "__main__":
    app.run(port=8080)