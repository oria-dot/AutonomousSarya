# reflex_dashboard_routes.py – Flask Reflex Endpoints for Signal Memory + Feedback

from flask import Blueprint, jsonify
from signal_memory_engine import SignalMemoryEngine
from reflex_feedback_core import ReflexFeedbackCore
from behavioral_tuner import BehavioralTuner

reflex_api = Blueprint("reflex_api", __name__)
memory = SignalMemoryEngine()
feedback = ReflexFeedbackCore(memory)
tuner = BehavioralTuner(memory, feedback)

@reflex_api.route("/memory/<symbol>")
def memory_route(symbol):
    """TODO: Add documentation."""
    return jsonify(memory.get_history(symbol.upper()))

@reflex_api.route("/tuning/<symbol>")
def tuning_route(symbol):
    """TODO: Add documentation."""
    return jsonify(feedback.analyze_symbol(symbol.upper()))

@reflex_api.route("/avoid")
def avoid_list():
    """TODO: Add documentation."""
    return jsonify(tuner.build_avoid_list())

@reflex_api.route("/reflex/log")
def full_memory():
    """TODO: Add documentation."""
    return jsonify(memory.get_history())