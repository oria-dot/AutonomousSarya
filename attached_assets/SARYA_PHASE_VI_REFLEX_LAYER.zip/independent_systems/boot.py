"""
SAYRA Boot Kernel
Initializes reflex core, system memory, and launches dispatcher
"""

import os
import time
from aria_dispatcher import launch_dispatcher

def initialize_kernel():
    print(">> SAYRA Kernel Initializing...")
    time.sleep(1)
    print(">> Reflex System Online.")
    time.sleep(1)

def main():
    initialize_kernel()
    launch_dispatcher()

if __name__ == "__main__":
    main()