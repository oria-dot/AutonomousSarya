from aria_core.auto.auto_healer import AutoHealingModule

import logging

logger = logging.getLogger(__name__)

class SecurityGuardian:
    def __init__(self, yellow_threshold=0.5, red_threshold=0.8):
        self.threat_levels = ["Green", "Yellow", "Red"]
        self.current_status = "Green"
        self.triggers = []
        self.yellow_threshold = yellow_threshold
        self.red_threshold = red_threshold

    def scan_system(self, anomaly_score):
        self.triggers = []
        if anomaly_score > self.red_threshold:
            self.current_status = "Red"
            self.triggers.append("Red Alert: Critical anomaly detected.")
        elif anomaly_score > self.yellow_threshold:
            self.current_status = "Yellow"
            self.triggers.append("Warning: Moderate anomaly.")
        else:
            self.current_status = "Green"
        logger.info(f"Security status: {self.current_status}, triggers: {self.triggers}")
        return self.current_status, self.triggers

    def activate_protocols(self):
        if self.current_status == "Red":
            return "Lockdown Mode Engaged"
        elif self.current_status == "Yellow":
            return "Monitoring Mode Enabled"
        return "All Clear"

    def run(self, anomaly_score):
        status, alerts = self.scan_system(anomaly_score)
        action = self.activate_protocols()
        return status, alerts, action

# Wrapped run with AutoHealing
if __name__ == '__main__':
    healer = AutoHealingModule()
    healer.run_with_recovery('ModuleRun', lambda: print(run()))
