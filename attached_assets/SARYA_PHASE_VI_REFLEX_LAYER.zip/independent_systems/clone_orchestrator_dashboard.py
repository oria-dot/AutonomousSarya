from flask import Flask, request, jsonify, render_template_string
from clone_orchestrator import CloneOrchestrator

app = Flask(__name__)
orchestrator = CloneOrchestrator()

TEMPLATE = """
<h2>ARIA Clone Orchestrator Dashboard</h2>
<p>Status: <a href='/status'>/status</a></p>
<p>Retire Idle: <a href='/retire'>/retire</a></p>
<form action="/assign" method="post">
    <label>Mission:</label>
    <input name="mission" size="40">
    <input type="submit" value="Assign to Available Clone">
</form>
<hr>
<pre>{{ response }}</pre>
"""

@app.route("/")
def index():
    """TODO: Add documentation."""
    return render_template_string(TEMPLATE, response="")

@app.route("/status")
def status():
    """TODO: Add documentation."""
    return jsonify(orchestrator.status_report())

@app.route("/assign", methods=["POST"])
def assign():
    """TODO: Add documentation."""
    mission = request.form.get("mission")
    result = orchestrator.assign_task(mission)
    return render_template_string(TEMPLATE, response=result)

@app.route("/retire")
def retire():
    """TODO: Add documentation."""
    result = orchestrator.retire_inactive_clones()
    return jsonify({"retired": result})

if __name__ == "__main__":
    app.run(port=8091)