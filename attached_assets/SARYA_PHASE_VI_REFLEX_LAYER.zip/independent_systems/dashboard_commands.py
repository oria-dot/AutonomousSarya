# dashboard_commands.py – /commands route for full emoji-enhanced command list

from flask import Blueprint

dashboard_commands = Blueprint("dashboard_commands", __name__)

@dashboard_commands.route("/commands")
def commands():
    """TODO: Add documentation."""
    return """
🧠 <b>System Status & Command Menu</b><br><br>

🧠 <b>Strategy & Status</b><br>
/start – System status<br>
/strategy – Current strategy<br>
/mode smart / swing / scalper – Switch modes<br>
/status – Full status report<br><br>

💰 <b>Income & Clone Ops</b><br>
/income – Total income<br>
/clones – List active clones<br>
/launch clone &lt;role&gt; – Deploy bot<br>
/retire clone &lt;id&gt; – Remove bot<br>
/profit map – Distribute income<br><br>

🌐 <b>Global Grid Control</b><br>
/grid – Global clone map<br>
/node &lt;id&gt; – Node details<br>
/region &lt;name&gt; – Filter by region<br>
/broadcast – Command all bots<br>
/scale – Trigger autoscale<br><br>

🔁 <b>Reflex AI Intelligence</b><br>
/memory &lt;symbol&gt; – Recent trades for symbol<br>
/tuning &lt;symbol&gt; – AI strategy suggestion<br>
/avoid – Risk symbols<br>
/recent signals – Latest signals<br><br>
"""