
from flask import Flask, jsonify, render_template_string
import json
import os

app = Flask(__name__)

STATUS_FILE = "profit_status.json"

@app.route("/")
def index():
    """TODO: Add documentation."""
    if os.path.exists(STATUS_FILE):
        with open(STATUS_FILE, "r") as f:
            status = json.load(f)
    else:
        status = {"message": "No status data yet."}

    html = '''
    <html>
        <head><title>ARIA Profit Dashboard</title></head>
        <body>
            <h1>Profit Loop Status</h1>
            <table border="1" cellpadding="5">
                <tr><th>Component</th><th>Status</th></tr>
                {% for name, state in status.items() %}
                <tr><td>{{ name }}</td><td>{{ state }}</td></tr>
                {% endfor %}
            </table>
        </body>
    </html>
    '''
    return render_template_string(html, status=status)

@app.route("/api/status")
def api_status():
    """TODO: Add documentation."""
    if os.path.exists(STATUS_FILE):
        with open(STATUS_FILE, "r") as f:
            return jsonify(json.load(f))
    return jsonify({"message": "No status data yet."})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)