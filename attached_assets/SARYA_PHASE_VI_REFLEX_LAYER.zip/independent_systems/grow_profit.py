
import argparse
import subprocess
import sys
import os

def run_profit_loop():
    """TODO: Add documentation."""
    os.system(f"{sys.executable} profit_loop.py")

def main():
    """TODO: Add documentation."""
    parser = argparse.ArgumentParser(description="ARIA Profit CLI")
    parser.add_argument("command", choices=["start", "trading", "affiliate", "saas", "wallet", "loop"], help="Profit command")

    args = parser.parse_args()

    if args.command == "loop" or args.command == "start":
        run_profit_loop()
    elif args.command == "trading":
from auto_trading_intelligence_3_0 import run
        run()
    elif args.command == "affiliate":
from affiliate_engine.affiliate_bot import run_affiliate_bot
        run_affiliate_bot()
    elif args.command == "saas":
from micro_saas_builder import launch_saas
        launch_saas()
    elif args.command == "wallet":
from income_wallet_router import start_wallet_monitor
        start_wallet_monitor()
    else:
        print("Unknown command")

if __name__ == "__main__":
    main()