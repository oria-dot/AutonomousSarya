# grid_dashboard.py – Flask Grid Visualizer

from flask import Flask, jsonify, render_template_string
from live_grid_controller import LiveGridController

app = Flask(__name__)
controller = LiveGridController()
controller.run()

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>ARIA Grid Monitor</title>
    <meta http-equiv="refresh" content="5">
    <style>
        body { font-family: sans-serif; background: #111; color: #0f0; }
        h1 { color: #0f0; }
        .node { margin: 8px 0; padding: 10px; border: 1px solid #0f0; }
    </style>
</head>
<body>
    <h1>Global Clone Grid</h1>
    {% for node in nodes %}
        <div class="node">
            <strong>{{ node.id }}</strong> | {{ node.role }} | {{ node.region }}<br>
            Status: {{ node.status }} | Income: ${{ node.income }} | Uptime: {{ node.uptime_sec }}s
        </div>
    {% endfor %}
</body>
</html>
"""

@app.route("/")
def dashboard():
    """TODO: Add documentation."""
    status = controller.get_grid_status()
    return render_template_string(HTML_TEMPLATE, nodes=status)

@app.route("/json")
def json_status():
    """TODO: Add documentation."""
    return jsonify(controller.get_grid_status())

if __name__ == "__main__":
    app.run(port=7861)