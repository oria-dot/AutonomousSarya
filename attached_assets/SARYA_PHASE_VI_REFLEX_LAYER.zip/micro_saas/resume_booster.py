import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Resume Booster Tool - Enhances Resume Content
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

def boost_resume(resume_text):
    """
    Enhances resume text with AI-powered formatting and branding.

    Args:
        resume_text (str): Original resume content.

    Returns:
        str: Boosted resume output.
    """
    improved = resume_text + "\nOptimized by ARIA."
    log_status("Resume successfully boosted.")
    return improved