class UniversalCommandHandler:
    def __init__(self):
        self.commands = {}
        self.subsystems = {}
        self.__name__ = "UniversalCommandHandler"
    def handle(self, cmd):
        print(f"[UniversalCommandHandler] Handling: {cmd}")
