# Package initializer for neural_map
