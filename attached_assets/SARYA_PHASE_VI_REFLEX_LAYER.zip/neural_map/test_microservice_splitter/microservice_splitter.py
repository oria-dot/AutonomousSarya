
# microservice_splitter.py
# Helps split large modules into callable microservice endpoints

def extract_microservice(logic_block, service_name):
    """TODO: Add documentation."""
    template = f"""
# {service_name}.py
# Auto-generated microservice

def handle_request(input_data):
    # Inserted Logic
    {logic_block}

    return "Processed"
"""
    return template

# Example usage:
# print(extract_microservice("result = input_data * 2", "double_service"))