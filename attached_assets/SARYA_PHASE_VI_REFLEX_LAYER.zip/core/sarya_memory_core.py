
import json
import os

MEMORY_FILE = "sarya_memory.json"

class SARYAMemory:
    def __init__(self):
        self.memory = {}
        self.load_memory()

    def load_memory(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, 'r') as f:
                    self.memory = json.load(f)
            except:
                self.memory = {}

    def save_memory(self):
        with open(MEMORY_FILE, 'w') as f:
            json.dump(self.memory, f, indent=4)

    def get(self, key, default=None):
        return self.memory.get(key, default)

    def set(self, key, value):
        self.memory[key] = value
        self.save_memory()

    def delete(self, key):
        if key in self.memory:
            del self.memory[key]
            self.save_memory()

memory = SARYAMemory()
