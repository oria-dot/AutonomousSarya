from aria_core.memory_core.snapshot_archiver import archive_snapshot

if __name__ == "__main__":
    archive_snapshot()