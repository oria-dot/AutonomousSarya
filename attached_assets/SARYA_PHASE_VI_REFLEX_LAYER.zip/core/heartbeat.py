
class SARYAHeartbeat:
    def __init__(self, memory, profile=None):
        self.memory = memory
        self.profile = profile
        self.pulse_count = 0

    def pulse(self, times=5):
        for _ in range(times):
            self.pulse_count += 1
            self.memory.store("heartbeat", {"pulse": self.pulse_count})
            print(f"[HEARTBEAT] Pulse {self.pulse_count} recorded.")
