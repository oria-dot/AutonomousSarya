
import json

COMMANDS = {
    "/status": "Report system status",
    "/memory": "Print current memory",
    "/reflex": "Trigger reflex feedback",
    "/strategy": "Activate trading strategy mode",
    "/clone": "Launch selected clone",
    "/soul": "Reflect on identity",
    "/heal": "Run dormant recovery scan",
}

def handle_command(cmd):
    cmd = cmd.strip().lower()
    if cmd in COMMANDS:
        print(f"[SARYA] Executing: {COMMANDS[cmd]}")
    else:
        print("[SARYA] Unknown command.")

def list_commands():
    for c, desc in COMMANDS.items():
        print(f"{c} — {desc}")

if __name__ == "__main__":
    list_commands()
