# memory_core.py – Persistent Memory Logger

import json, os
from datetime import datetime

class MemoryEngine:
    """TODO: Add documentation."""
    def __init__(self, context, path="aria_core/logs/memory_log.json"):
    """TODO: Add documentation."""
        self.context = context
        self.path = path
        self._load()

    def _load(self):
    """TODO: Add documentation."""
        if os.path.exists(self.path):
            with open(self.path, "r") as f:
                self.db = json.load(f)
        else:
            self.db = {}

    def save(self):
    """TODO: Add documentation."""
        with open(self.path, "w") as f:
            json.dump(self.db, f, indent=2)

    def log(self, module, action, outcome):
    """TODO: Add documentation."""
        timestamp = datetime.now().isoformat()
        self.db.setdefault(module, []).append({
            "timestamp": timestamp,
            "action": action,
            "outcome": outcome
        })
        self.save()