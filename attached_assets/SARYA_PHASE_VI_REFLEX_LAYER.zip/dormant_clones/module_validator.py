# Module Validator & Dependency Map
REQUIRED_MODULES = [
    'core/aria.py',
    'core/meta_command.py',
    'clones/clone_manager.py',
    'finance/auto_income_router.py',
    'core/security_guardian.py'
]

import os

def validate_modules(base_path='.'):
    """TODO: Add documentation."""
    print('--- ARIA BOOT VALIDATOR ---')
    for module in REQUIRED_MODULES:
        path = os.path.join(base_path, module)
        if not os.path.isfile(path):
            print(f'[ERROR] Missing required module: {module}')
            return False
        else:
            print(f'[OK] {module}')
    print('[SUCCESS] All core modules validated.')
    return True