import streamlit as st
import os
import json
from pathlib import Path

st.set_page_config(layout="wide", page_title="ARIA Dashboard")

st.title("ARIA Clone Status Dashboard")

log_dir = Path("logs/memory_journal")
if not log_dir.exists():
    st.warning("No memory journal logs found.")
else:
    files = sorted(log_dir.glob("*.jsonl"))
    for f in files:
        st.subheader(f.name.replace(".jsonl", ""))
        with open(f, "r") as log_file:
            lines = log_file.readlines()[-5:]
            for line in lines:
                entry = json.loads(line)
st.text(f"[{entry['timestamp']}] {entry['thought']}")