import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Clone Warfare Protocol Core
from clones.clone_intelligence_core import register_clone
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

def launch_clone(clone_id, mission, mode='war'):
    """
    Launches a clone in a specified operational mode.

    Args:
        clone_id (str): Clone identifier.
        mission (str): Operational objective.
        mode (str): Launch mode (default: 'war').

    Returns:
        None
    """
    register_clone(clone_id, mission)
    log_status(f"[CLONE LAUNCHED] ID: {clone_id} | Mission: {mission} | Mode: {mode}")

def assign_mission_tree(clone_id, mission_tree):
    """
    Assigns a structured mission tree to an AI clone.

    Args:
        clone_id (str): Target clone.
        mission_tree (str): Hierarchical mission specification.

    Returns:
        None
    """
    log_status(f"[MISSION TREE] Assigning to {clone_id}: {mission_tree}")