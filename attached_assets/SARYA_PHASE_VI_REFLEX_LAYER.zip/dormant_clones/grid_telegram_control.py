# grid_telegram_control.py – Telegram Bot Control for Global Grid

from grid_node_engine import GridNodeEngine

class TelegramGridInterface:
    """TODO: Add documentation."""
    def __init__(self):
"""TODO: Add documentation."""
        self.engine = GridNodeEngine()

    def handle_command(self, text):
    """TODO: Add documentation."""
        parts = text.strip().split()
        if len(parts) == 0:
            return "Invalid grid command."

        cmd = parts[0]
        args = parts[1:]

if cmd == "/grid":
            summary = self.engine.get_all_status()
            return "\n".join([f"{n['id']} | {n['role']} | {n['region']} | ${n['income']}" for n in summary])

elif cmd == "/node" and len(args) > 0:
            node_id = args[0]
            node = self.engine.nodes.get(node_id)
            return str(node.get_status()) if node else "Node not found."

elif cmd == "/region" and len(args) > 0:
            region = args[0]
            filtered = [n.get_status() for n in self.engine.nodes.values() if n.region == region]
            return "\n".join([f"{n['id']} | {n['role']} | ${n['income']}" for n in filtered]) or "No nodes in region."

elif cmd == "/broadcast":
            for node in self.engine.nodes.values():
                node.assign_mission("broadcast_mission")
                node.complete_mission(100)
            return "Mission broadcasted to all nodes."

        return "Unknown grid command."