import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# AI-Enhanced Cloning with Real-Time Feedback
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

CLONE_FEEDBACK_LOG = []

def clone_feedback(clone_id, task_result):
    """
    Records feedback from a clone after task completion.

    Args:
        clone_id (str): Identifier for the AI clone.
        task_result (str): Description or result of the task performed.

    Returns:
        None
    """
    feedback = {
        'clone_id': clone_id,
        'task_result': task_result,
    }
    CLONE_FEEDBACK_LOG.append(feedback)
    log_status(f"[FEEDBACK LOG] Clone {clone_id}: {task_result}")

def get_feedback_logs():
    """
    Returns a list of all collected feedback logs from clones.

    Returns:
        list: List of feedback dictionaries.
    """
    return CLONE_FEEDBACK_LOG