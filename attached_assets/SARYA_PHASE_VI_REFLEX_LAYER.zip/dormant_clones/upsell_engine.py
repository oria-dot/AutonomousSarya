
from datetime import datetime

def generate_upsell(product_name):
    """TODO: Add documentation."""
    upsells = [
        f"{product_name} Premium: Includes 1-on-1 strategy session and lifetime updates.",
        f"{product_name} Clone Pack: Get 3 clones of this tool to deploy for clients or resale.",
        f"{product_name} VIP Access: Early access to all future features, plus private Telegram support."
    ]

    upsell_offer = {
        "base_product": product_name,
        "upsell_options": upsells,
        "created_at": datetime.now().isoformat()
    }

    print(f"[ProfitStacker] Upsell offers for {product_name}:")
for upsell in upsell_offer["upsell_options"]:
        print(f"- {upsell}")

    return upsell_offer