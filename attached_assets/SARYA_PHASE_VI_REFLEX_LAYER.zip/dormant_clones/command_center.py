# command_center.py – Unified Command Core for Voice + Telegram

class CommandCenter:
    """TODO: Add documentation."""
    def __init__(self, context):
"""TODO: Add documentation."""
        self.context = context
        self.commands = {
"/start": self.get_status,
"/mode smart": lambda: self.set_mode("smart"),
"/mode swing": lambda: self.set_mode("swing"),
"/mode scalper": lambda: self.set_mode("scalper"),
"/strategy": self.show_strategy,
"/income": self.show_income,
"/clones": self.show_clones
        }

    def get_status(self):
    """TODO: Add documentation."""
        return f"Status: {self.context.get('status', [])[-1:]}, Mode: {self.context.get('mode')}"

    def set_mode(self, mode):
    """TODO: Add documentation."""
        self.context["mode"] = mode
        return f"Mode switched to: {mode}"

    def show_strategy(self):
    """TODO: Add documentation."""
        return f"Strategy: {self.context.get('strategy')}"

    def show_income(self):
    """TODO: Add documentation."""
        return f"Income: {self.context.get('income')}"

    def show_clones(self):
    """TODO: Add documentation."""
        return f"Clones: {self.context.get('clones', [])}"

    def execute(self, command):
    """TODO: Add documentation."""
        func = self.commands.get(command)
        return func() if func else f"Unknown command: {command}"