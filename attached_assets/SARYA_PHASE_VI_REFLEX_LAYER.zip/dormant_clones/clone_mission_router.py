
# clone_mission_router.py

import os

class CloneMissionRouter:
    def __init__(self):
        self.clones_directory = "clones"
        self.available_clones = self.scan_clones()

    def scan_clones(self):
        print("[CLONE ROUTER] Scanning available clones...")
        clones = []
        if os.path.exists(self.clones_directory):
            for f in os.listdir(self.clones_directory):
                if f.endswith(".py"):
                    clones.append(f)
        print(f"[CLONE ROUTER] Found {len(clones)} clone(s): {clones}")
        return clones

    def route_to_clone(self, mission_name):
        for clone in self.available_clones:
            if mission_name.lower() in clone.lower():
                path = os.path.join(self.clones_directory, clone)
                print(f"[CLONE ROUTER] Routing to: {clone}")
                os.system(f"python3 {path}")
                return
        print(f"[CLONE ROUTER] No matching clone found for mission: {mission_name}")

if __name__ == "__main__":
    print("[CLONE ROUTER] Starting demo mission routing...")
    router = CloneMissionRouter()
    router.route_to_clone("freelance")  # Example: will run if `freelance` clone exists
