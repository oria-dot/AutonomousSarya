import redis
import json
import os

REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))

redis_conn = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=0)

MISSION_RESULT_QUEUE = "clone_mission_results"

def push_result(clone_name, result):
    """TODO: Add documentation."""
    payload = {
        "clone": clone_name,
        "result": result
    }
    redis_conn.rpush(MISSION_RESULT_QUEUE, json.dumps(payload))

def pop_result():
    """TODO: Add documentation."""
    raw = redis_conn.lpop(MISSION_RESULT_QUEUE)
    if raw:
        return json.loads(raw)
    return None