import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Clone Manager — Oversees Clone Deployment
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

clones = []

def deploy_clone(clone_name):
    """
    Registers and logs the deployment of a new AI clone.

    Args:
        clone_name (str): Identifier or label for the clone.

    Returns:
        list: Current list of deployed clones.
    """
    clones.append(clone_name)
    log_status(f"Deployed clone: {clone_name}")
    return clones