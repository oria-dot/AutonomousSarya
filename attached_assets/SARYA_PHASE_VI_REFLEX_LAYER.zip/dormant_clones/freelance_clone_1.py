import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Freelance Clone Task Execution
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

def apply_to_job(job_data):
    """
    Simulates a freelance clone applying to a job post.

    Args:
        job_data (dict): Dictionary containing 'title' and 'platform' keys.

    Returns:
        None
    """
    title = job_data.get("title", "Unknown")
    platform = job_data.get("platform", "Unknown")

    log_status(f"Applying to: {title} on {platform}")
    # Simulated logic to apply to job