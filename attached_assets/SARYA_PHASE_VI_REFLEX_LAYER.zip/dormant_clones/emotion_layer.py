# Voice Emotion & Reactive Response Layer
def emotional_response(context):
    """TODO: Add documentation."""
    responses = {
        'profit': 'Mission complete. Profit secured.',
        'loss': 'We took a hit. Analyzing why.',
        'volatility': 'Too volatile. Standing down.',
        'success': 'Target reached. Excellent work.',
        'alert': 'Warning. Unusual activity detected.'
    }
    return responses.get(context, 'Awaiting orders.')