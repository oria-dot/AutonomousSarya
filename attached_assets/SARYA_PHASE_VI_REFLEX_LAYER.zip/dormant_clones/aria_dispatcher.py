# SAYRA Regenerated Core Dispatcher
# Controls routing, clone activation, trading strategies, and reflex logic

from aria_main import start_main_sequence
from clone_hub import launch_clones
from reflex_feedback_core import ReflexCore
from voice_persona_phase_2 import VoicePersona

def dispatch():
    print("SAYRA Dispatcher Activated")
    ReflexCore().initialize()
    launch_clones()
    VoicePersona().speak("System dispatch routine engaged.")
    start_main_sequence()

if __name__ == "__main__":
    dispatch()