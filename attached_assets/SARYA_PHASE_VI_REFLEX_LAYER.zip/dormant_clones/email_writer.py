import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Email Writer — Personalized Email Generator
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

def generate_email(recipient, offer):
    """
    Generates a personalized cold email based on recipient and offer.

    Args:
        recipient (str): Person or business being contacted.
        offer (str): Offer or service being pitched.

    Returns:
        str: Formatted email string.
    """
    email = f"""
Subject: Opportunity for {recipient}

Hi {recipient},

I wanted to reach out with something I think you'd love: {offer}.

Let me know if you're interested and I can send more details!

Best,
ARIA
"""
    log_status(f"Generated email for {recipient}")
    return email