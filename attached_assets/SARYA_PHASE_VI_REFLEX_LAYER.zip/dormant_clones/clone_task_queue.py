import redis
import json
import os

# Connect to Redis (use host from env if defined)
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))

redis_conn = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=0)

CLONE_TASK_QUEUE = "clone_task_queue"

def enqueue_mission(clone_name, mission):
    """TODO: Add documentation."""
    task = {
        "clone": clone_name,
        "mission": mission
    }
    redis_conn.rpush(CLONE_TASK_QUEUE, json.dumps(task))

def dequeue_mission():
    """TODO: Add documentation."""
    task_data = redis_conn.lpop(CLONE_TASK_QUEUE)
    if task_data:
        return json.loads(task_data)
    return None
def enqueue_task(queue, task, ttl=3600):
    """TODO: Add documentation."""
    task_id = f"task:{int(time.time() * 1000)}"
    r.set(task_id, task)
    r.expire(task_id, ttl)  # auto-expire task after TTL
    r.rpush(queue, task_id)
    return task_id