"""
VoicePersona – AI tone and voice modulation layer.
"""

import random
import logging

logger = logging.getLogger(__name__)

class VoicePersona:
    """
    Provides an interface for selecting and expressing a message using a simulated tone/persona.
    """

    def __init__(self):
        """
        Initialize with preset voice profiles.
        """
        self.voices = ["Confident", "Calm", "Analytical", "Empathetic"]
        self.current_voice = "Confident"
        self.last_message = ""

    def set_voice(self, mood):
        """
        Set the persona voice based on a mood. Fallback to random if not matched.

        :param mood: Desired voice/mood
        :return: Voice selected
        """
        if mood in self.voices:
            self.current_voice = mood
        else:
            self.current_voice = random.choice(self.voices)
        logger.info(f"VoicePersona set to: {self.current_voice}")
        return self.current_voice

    def speak(self, message):
        """
        Simulate speaking a message in the current voice.

        :param message: Text to express
        :return: Rendered voice message
        """
        self.last_message = message
        result = f"[{self.current_voice} Voice] {message}"
        logger.info(f"VoicePersona spoke: {result}")
        return result

    def run(self, mood, message):
        """
        Full cycle: set voice based on mood and deliver a message.

        :param mood: Desired mood
        :param message: Text to speak
        :return: Rendered voice output
        """
        self.set_voice(mood)
        return self.speak(message)