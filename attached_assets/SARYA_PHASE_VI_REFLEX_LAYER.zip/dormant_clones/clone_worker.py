import time
from clone_task_queue import dequeue_mission
from clone_hub import CloneHub
from mission_feedback_queue import push_result
from clone_memory_store import save_memory

hub = CloneHub()

def run_clone_worker():
    """TODO: Add documentation."""
    print("Clone Worker is running. Waiting for missions...")
    while True:
        task = dequeue_mission()
        if task:
name = task["clone"]
mission = task["mission"]
            print(f"[CloneWorker] Received task: {name} -> {mission}")
            try:
                hub.deploy_clone(name, mission)
                push_result(name, f'Mission "{mission}" completed')
                save_memory(name, mission, "completed")
            except Exception as e:
                print(f"[CloneWorker] Error running task: {e}")
        else:
            time.sleep(1)

if __name__ == "__main__":
    run_clone_worker()