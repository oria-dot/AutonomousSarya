import streamlit as st
import json
from pathlib import Path

st.set_page_config(page_title="GPT Brain Viewer", layout="wide")
st.title("GPT Knowledge Base")

path = Path("aria_core/memory_core/gpt_knowledge_base.json")
if not path.exists():
    st.error("GPT Knowledge Base not found.")
else:
    with path.open("r") as f:
        data = json.load(f)

    st.subheader("All Recorded Thoughts")
    for entry in reversed(data.get("logs", [])[-20:]):
st.markdown(f"**{entry['timestamp']}** — {entry.get('thought')}")
        if entry.get("decision"):
st.code(f"Decision: {entry['decision']}")
        if entry.get("strategy"):
st.text_area("Strategy", entry["strategy"], height=80)

    st.info("Showing latest 20 GPT thoughts. Clone decisions and strategies below.")

    st.subheader("Strategies")
    for strat in data.get("strategies", [])[-5:]:
st.code(strat["strategy"])

    st.subheader("Decisions")
    for d in data.get("decisions", [])[-5:]:
st.write(f"{d['timestamp']}: {d['decision']}")