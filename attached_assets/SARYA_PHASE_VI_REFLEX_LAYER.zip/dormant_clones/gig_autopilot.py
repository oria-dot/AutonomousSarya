import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# Freelance Gig Autopilot - Autonomous Job Application
from freelance_systems.job_scraper import fetch_jobs
from clones.freelance_clone_1 import apply_to_job
# [FIXED] from core.aria_status import log_status (original import disabled — module not found)

def run_autopilot():
    """
    Automates job application workflow by scraping and applying to gigs.

    Returns:
        None
    """
    log_status("Running freelance autopilot...")
    jobs = fetch_jobs()
    for job in jobs:
        apply_to_job(job)