
from flask import Flask, jsonify
import os
import importlib.util

app = Flask(__name__)

@app.route('/')
def home():
    return "<h1>SARYA Navigator Flask Panel</h1><p>Use /status to get subsystem status.</p>"

@app.route('/status')
def status():
    try:
        engine_path = os.path.join(os.getcwd(), 'neural_map', 'sarya_engine.py')
        spec = importlib.util.spec_from_file_location("sarya_engine", engine_path)
        sarya_engine = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(sarya_engine)
        engine = sarya_engine.SARYAEngine()
        return jsonify({"subsystems": list(engine.subsystems.keys())})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
