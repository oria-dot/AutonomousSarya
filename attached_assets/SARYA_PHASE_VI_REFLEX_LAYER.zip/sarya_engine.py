


def load_neural_directory_map(self, path="neural_map"):
    self.neural_connections = {}
    base_path = os.path.abspath(path)
    if not os.path.exists(base_path):
        print("[NEURAL MAP] No neural directory structure found.")
        return
    for folder in os.listdir(base_path):
        folder_path = os.path.join(base_path, folder)
        if os.path.isdir(folder_path):
            self.neural_connections[folder] = []
            for file in os.listdir(folder_path):
                if file.endswith(".py"):
                    self.neural_connections[folder].append(file)
    print(f"[NEURAL MAP] {len(self.neural_connections)} subsystems loaded from neural tree.")



def speak(text):
    try:
        import pyttsx3
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print(f"[VOICE ERROR] {e}")

def announce_neural_awareness(self):
    if not hasattr(self, 'neural_connections'):
        print("[VOICE] No neural map loaded.")
        return
    speak("Commander, booting neural awareness systems.")
    for subsystem, files in self.neural_connections.items():
        speak(f"Subsystem {subsystem} contains {len(files)} modules.")
