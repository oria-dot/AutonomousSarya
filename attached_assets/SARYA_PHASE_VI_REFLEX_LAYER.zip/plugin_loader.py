import os
import importlib.util
import logging

PLUGIN_DIR = "plugins"

def load_plugins():
    loaded_plugins = []
    if not os.path.exists(PLUGIN_DIR):
        os.makedirs(PLUGIN_DIR)

    for filename in os.listdir(PLUGIN_DIR):
        if filename.endswith(".py"):
            plugin_name = filename[:-3]
            path = os.path.join(PLUGIN_DIR, filename)
            spec = importlib.util.spec_from_file_location(plugin_name, path)
            mod = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(mod)
                if hasattr(mod, "run_plugin"):
                    mod.run_plugin()
                    loaded_plugins.append(plugin_name)
            except Exception as e:
                logging.warning(f"Plugin {plugin_name} failed: {str(e)}")

    return loaded_plugins