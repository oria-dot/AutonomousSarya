def spiritual_guidance(event_log):
    if "clone failed" in event_log.lower():
        return "This path resists. Pause and realign."
    elif "risk high" in event_log.lower():
        return "Storm approaches. Anchor your actions."
    elif "success" in event_log.lower():
        return "Green light. Momentum flows."
    return "Observe in stillness."