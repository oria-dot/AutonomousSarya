import sarya_engine

"""
Overwatch Protocol Control Panel
Linked from: aria_dispatcher_gui_telegram_voice_dashboard.py
Purpose: Launch the master dashboard interface and control central mission execution
"""

def launch_dashboard():
    try:
# [FIXED] from core.dashboard_commands import initialize_dashboard (original import disabled — module not found)
        from clones.clone_manager import load_clones
        from reflex.reflex_feedback_core import engage_reflex_loop
        from dispatcher.grid_dispatcher import start_grid_control

        print("[OVERWATCH] Launching Central Dashboard...")
        initialize_dashboard()
        load_clones()
        engage_reflex_loop()
        start_grid_control()
        print("[OVERWATCH] All systems initialized.")

    except Exception as e:
        print(f"[OVERWATCH ERROR] Failed to launch dashboard: {e}")
